// homepage.js — FINAL (with live status per file and cancellation logic)
const API_BASE = "http://localhost:8001";
const POLL_INTERVAL = 3000;

document.addEventListener("DOMContentLoaded", () => {
  console.log("PPI Upload Page Loaded");

  const uploadBtn = document.getElementById("uploadBtn");
  const clearBtn = document.getElementById("clearBtn");
  // This button is used for global cancellation
  const cancelAllBtn = document.getElementById("cancelBtn"); 
  const statusEl = document.getElementById("status");
  const jobInfo = document.getElementById("jobInfo");
  const downloadArea = document.getElementById("downloadArea");
  const resultArea = document.getElementById("resultArea");
  
  // State variables for cancellation and polling
  let activeTaskPairs = []; // Stores [docType, taskId]
  let stopPolling = false; 

  function show(msg, color = "orange") {
    statusEl.textContent = msg;
    statusEl.style.color = color;
  }

  // Helper function to create the cancel button HTML/element
  function createCancelButton(taskId, docType) {
    return `<button 
              id="cancel-btn-${taskId}" 
              data-task-id="${taskId}" 
              data-doc-type="${docType}"
              class="cancel-task-btn"
              style="margin-left: 10px; font-size: 0.7em; padding: 2px 5px; cursor: pointer; background: #dc3545; color: white; border: none; border-radius: 3px;"
              >Cancel</button>`;
  }

  // Function to handle task cancellation via API
  async function cancelTask(taskId, docType) {
    const el = document.getElementById(`status-${taskId}`);
    const cancelBtn = document.getElementById(`cancel-btn-${taskId}`);
    
    if (el) el.textContent = "Cancelling...";
    if (cancelBtn) cancelBtn.disabled = true;

    try {
      const token = localStorage.getItem("token");
      if (!token) throw new Error("Login required");

      const res = await fetch(`${API_BASE}/cancel_task/${taskId}`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
      });

      const data = await res.json();
      
      if (!res.ok) {
         throw new Error(data.detail || "Cancellation failed");
      }

      // Update status element with cancellation result
      const message = data.message || "Task Revoked";
      const color = message.includes("already") ? "gray" : "red";
      if (el) {
        // Use a clearer status message
        const finalStatus = message.includes("already") ? data.state.toUpperCase() : "REVOKED";
        el.textContent = finalStatus;
        el.style.color = color;
      }
      if (cancelBtn) cancelBtn.hidden = true; // Hide once successfully revoked or already done

      console.log(`Task ${taskId} (${docType}) cancelled/revoked:`, data.message);

    } catch (e) {
      console.error(`Error cancelling task ${taskId}:`, e);
      if (el) el.textContent = "Error Cancelling";
      if (cancelBtn) cancelBtn.disabled = false;
    }
  }

  uploadBtn.onclick = async () => {
    console.log("Upload clicked");
    show("Uploading...", "orange");
    uploadBtn.disabled = true;
    if (cancelAllBtn) cancelAllBtn.disabled = true; // Disable global cancel until tasks start
    resultArea.hidden = true;

    const fd = new FormData();
    const files = {
      rfp: document.querySelector("input[name='tender']")?.files[0],
      gtp: document.querySelector("input[name='gtp']")?.files[0],
      response: document.querySelector("input[name='response']")?.files[0],
      other: document.querySelector("input[name='other']")?.files[0]
    };

    if (!Object.values(files).some(f => f)) {
      show("No file selected", "red");
      uploadBtn.disabled = false;
      return;
    }

    for (const key in files) {
      if (files[key]) fd.append(key, files[key]);
    }

    try {
      const token = localStorage.getItem("token");
      if (!token) throw new Error("Login required");

      const res = await fetch(`${API_BASE}/upload_documents`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: fd
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Upload failed");

      resultArea.hidden = false;

      // 🧩 Map each document type to its task ID
      const taskPairs = data.task_ids; // e.g. [["RFP", "abc123"], ["GTP", "xyz456"]]
      activeTaskPairs = taskPairs; // Store pairs globally for cancellation
      stopPolling = false; // Reset stop polling flag
      if (cancelAllBtn) cancelAllBtn.disabled = false; // Enable global cancel

      // Build the status list with individual cancel buttons
      jobInfo.innerHTML = `<ul>${taskPairs
        .map(([doc, id]) => `<li>${doc}: <code>${id.slice(0, 8)}...</code> → 
          <span id="status-${id}">Waiting...</span>
          ${createCancelButton(id, doc)}
        </li>`)
        .join("")}</ul>`;
      
      // Attach click handlers to the newly created cancel buttons
      taskPairs.forEach(([doc, id]) => {
        const btn = document.getElementById(`cancel-btn-${id}`);
        if (btn) {
          btn.onclick = () => cancelTask(id, doc);
        }
      });

      show("Processing started...", "orange");

      await pollTaskStatus(taskPairs);

      if (!stopPolling) {
        // Check if all tasks were SUCCESS before showing report button
        const allSuccessful = taskPairs.every(([, id]) => {
            const el = document.getElementById(`status-${id}`);
            return el && el.textContent === "SUCCESS";
        });

        if (allSuccessful) {
            show("✅ All tasks completed! Generate report below", "green");
            addReportButton(taskPairs.map(t => t[1]));
        } else {
             show("Processing finished with errors or cancellation. Check task status.", "red");
        }
      } else {
         show("Processing interrupted/cancelled.", "gray");
      }

    } catch (e) {
      console.error(e);
      show("Error: " + e.message, "red");
    } finally {
      uploadBtn.disabled = false;
      if (cancelAllBtn) {
        cancelAllBtn.disabled = true;
        cancelAllBtn.textContent = "cancel";
      }
    }
  };

  // Implement the global cancel button logic
  if (cancelAllBtn) {
    cancelAllBtn.onclick = async () => {
      stopPolling = true; // Signal the polling loop to stop
      cancelAllBtn.disabled = true;
      cancelAllBtn.textContent = "Cancelling All...";
      show("Attempting to cancel all tasks...", "red");

      // Attempt to cancel all tasks concurrently
      const cancellationPromises = activeTaskPairs.map(([docType, taskId]) => 
          cancelTask(taskId, docType)
      );

      await Promise.allSettled(cancellationPromises);

      // Status will be updated by individual cancelTask calls
      cancelAllBtn.textContent = "Canceled";
    };
  }

  // 🕒 Poll each task's status and update live
  async function pollTaskStatus(taskPairs) {
    console.log("🟢 pollTaskStatus started with:", taskPairs);
    let allDone = false;

    while (!allDone && !stopPolling) {
      console.log("🔄 Poll iteration starting...");
      allDone = true;

      for (const [docType, taskId] of taskPairs) {
        // Get the current status text to skip API call if already in a final state
        const el = document.getElementById(`status-${taskId}`);
        const currentText = el?.textContent.toUpperCase();
        if (["SUCCESS", "FAILURE", "REVOKED", "TASK REVOKED", "ERROR CANCELLING"].includes(currentText)) {
             continue; 
        }

        try {
          const res = await fetch(`${API_BASE}/task_status/${taskId}`, {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          });

          const data = await res.json();
          const state = (data.state || "PENDING").toUpperCase();
          console.log(`📊 ${docType} ${taskId} ${state}`);

          const cancelBtn = document.getElementById(`cancel-btn-${taskId}`);
          
          if (el) {
            let color = "gray";
            if (state === "SUCCESS") color = "green";
            else if (state === "STARTED") color = "orange";
            else if (state === "FAILURE" || state === "REVOKED") color = "red";
            el.textContent = state;
            el.style.color = color;

            if (["SUCCESS", "FAILURE", "REVOKED"].includes(state)) {
                if (cancelBtn) cancelBtn.hidden = true; // Hide cancel button when done/failed/revoked
            }
          }

          if (!["SUCCESS", "FAILURE", "REVOKED"].includes(state)) {
            allDone = false; // continue polling
          }

        } catch (err) {
          console.error("Polling error:", err);
          allDone = false; 
        }
      }

      // Only wait if we're not done and haven't been asked to stop
      if (!allDone && !stopPolling) {
        await new Promise(r => setTimeout(r, POLL_INTERVAL));
      }
    }
    
    console.log("🛑 Polling finished or cancelled.");
    if (cancelAllBtn) {
       cancelAllBtn.disabled = true; 
       cancelAllBtn.textContent = "Cancel"; 
    }
  }

  function addReportButton(ids) {
    if (document.getElementById("reportBtn")) return;
    const btn = document.createElement("button");
    btn.id = "reportBtn";
    btn.textContent = "Generate Final Report";
    btn.style = "margin:15px 0; padding:10px 20px; background:green; color:white; border:none; border-radius:5px; font-weight:bold;";
    btn.onclick = async () => {
      btn.textContent = "Generating...";
      btn.disabled = true;
      try {
        const res = await fetch(`${API_BASE}/generate_final_report`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ task_ids: ids })
        });
        const d = await res.json();
        if (res.ok) {
          downloadArea.innerHTML = `
            <p><strong>Report Ready:</strong></p>
            <a href="${d.excel_path}" target="_blank" style="margin:0 10px;">Excel</a>
            <a href="${d.word_path}" target="_blank">Word</a>
          `;
        } else {
          throw new Error(d.detail);
        }
      } catch (e) {
        alert("Report failed: " + e.message);
      } finally {
        btn.disabled = false;
        btn.textContent = "Generate Final Report";
      }
    };
    resultArea.appendChild(btn);
  }
});