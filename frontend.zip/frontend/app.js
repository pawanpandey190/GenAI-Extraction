const sign_in_btn = document.querySelector("#sign-in-btn");
const sign_up_btn = document.querySelector("#sign-up-btn");
const container = document.querySelector(".container");

sign_up_btn.addEventListener('click', () => {
  container.classList.add("sign-up-mode");
});

sign_in_btn.addEventListener('click', () => {
  container.classList.remove("sign-up-mode");
});

// login connector
document.addEventListener("DOMContentLoaded", () => {
document.getElementById("login-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const username = document.getElementById("username_login").value;
  const password = document.getElementById("password_login").value;
  console.log(username)
  console.log(password)

  try {
      // const body = new URLSearchParams();
      // body.append("username", username);
      // body.append("password", password);
    const response = await fetch("http://localhost:8001/login", {
      method: "POST",
      headers: {
        
        "Content-Type": "application/json",
        // "Content-Type": "application/x-www-form-urlencoded",
      },
      body: JSON.stringify({ username: username, password: password }),
      // body:body
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.detail || "Login failed");
    }

    const data = await response.json();
    localStorage.setItem("token", data.access_token);
    localStorage.setItem("username", username);
    alert("Login successful! Redirecting...");
    window.location.href = "chat.html"; // Adjust to your dashboard page
  } catch (error) {
    alert("Login failed: " + error.message);
  }
});
});

// sign-up container
document.addEventListener("DOMContentLoaded", () => {
document.getElementById("signup-form").addEventListener("submit", async (e) => {
  e.preventDefault();
  const username = document.getElementById("signup-username").value;
  const email = document.getElementById("signup-email").value;
  const password = document.getElementById("signup-password").value;
  console.log(email)
  console.log(password)
  console.log(username)

  try {
    const response = await fetch("http://localhost:8001/signup", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Accept": "application/json",
      },
      body: JSON.stringify({ username, email, password }),
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.detail || "Signup failed");
    }

    const data = await response.json();
    localStorage.setItem("token", data.access_token);
    alert("Signup successful! Redirecting...");
    window.location.href = "chat.html"; // Adjust to your dashboard page
  } catch (error) {
    alert("Signup failed: " + error.message);
  }
});
});


