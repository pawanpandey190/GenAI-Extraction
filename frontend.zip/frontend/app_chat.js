// -------------------- CONFIG --------------------
const API_BASE = "http://localhost:8001";

// -------------------- DOM --------------------
let fileInput = null;
let sendBtn = null;
let uploadAndSendBtn = null;
let promptEl = null;
let messagesEl = null;
let historyList = null;
let newChatBtn = null;
let logoutBtn = null;
let usernameDisplay = null;
let footerUsername = null;
let bug_debug = '';
let isStreaming = false; // Controls the typewriter effect state


// -------------------- STATE --------------------
let token = localStorage.getItem("token");
let username = localStorage.getItem("username") || "Guest";

// -------------------- HELPERS --------------------
function authHeaders() {
    const token = localStorage.getItem("token");
    return token ? { "Authorization": "Bearer " + token } : {};
}

function pushMessage(role, text) {
    if (!messagesEl) {
        console.error("messagesEl is null, cannot push message");
        return null;
    }
    if (!text || typeof text !== "string") {
        console.warn(`Invalid or empty text for ${role} message:`, text);
        return null;
    }
    const el = document.createElement("div");
    el.className = "msg " + (role === "user" ? "user" : "");
    el.innerHTML = `
        <div class="msg meta">${role.toUpperCase()} • ${new Date().toLocaleString()}</div>
        <div class="msg-content">${text}</div>`; // Added msg-content for targeting
    messagesEl.appendChild(el);
    
    // Only scroll immediately for user messages and initial history load
    if (role === 'user') {
        messagesEl.scrollTop = messagesEl.scrollHeight;
    }
    console.log(`Pushed ${role} message:`, text);
    return el; // Return the new element
}

function renderSources(sources) {
    if (!messagesEl) {
        console.error("messagesEl is null, cannot render sources");
        return;
    }
    if (!sources || !Array.isArray(sources) || sources.length === 0) {
        console.log("No valid sources to render:", sources);
        return;
    }
    const cont = document.createElement("div");
    cont.className = "msg sources";
    cont.innerHTML = `<div class="msg meta">SOURCES</div>` +
        sources.map(s => {
            if (typeof s === "string") {
                return `<div style="margin-top:6px;">${s.slice(0, 500)}</div>`;
            } else {
                return `<div style="margin-top:6px;">
                            <strong>${s.title || s.id || s.filename || "source"}</strong>
                            <div class="muted small">${(s.text_snippet || "").slice(0, 300)}</div>
                        </div>`;
            }
        }).join("");
    messagesEl.appendChild(cont);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    console.log("Rendered sources:", sources);
}

function toast(msg) {
    alert(msg);
}

function handleLoggedOut() {
    toast("Session expired or logged out.");
    window.location.href = "/index.html";
}

/**
 * Simulates a typing effect for the assistant's response.
 * @param {HTMLElement} element - The assistant message element.
 * @param {string} text - The full response text.
 * @param {number} delay - Delay between characters in ms.
 */
function typewriterEffect(element, text, delay = 25) {
    let i = 0;
    const contentEl = element.querySelector('.msg-content');
    if (!contentEl) return;
    
    // 1. Clear the placeholder/temporary text
    contentEl.textContent = ''; 
    
    // 2. Add a blinking cursor placeholder
    const cursor = document.createElement('span');
    cursor.className = 'typing-cursor';
    cursor.textContent = '|';
    contentEl.appendChild(cursor);

    isStreaming = true; // Set streaming state to true

    function typing() {
        if (i < text.length) {
            // Insert the new character before the cursor
            cursor.insertAdjacentText('beforebegin', text.charAt(i));
            i++;
            // Scroll to bottom with every character
            messagesEl.scrollTop = messagesEl.scrollHeight; 
            setTimeout(typing, delay);
        } else {
            // Remove the cursor and reset state when finished
            cursor.remove();
            isStreaming = false;
        }
    }

    typing();
}

// -------------------- CHAT HISTORY --------------------
let isLoadingHistory = false;

async function loadHistory(autoLoad = true) {
    // Prevent multiple parallel history loads
    if (isLoadingHistory) {
        console.log("Skipping loadHistory — already running.");
        return;
    }
    isLoadingHistory = true;

    try {
        if (!token) {
            console.log("No token found — skipping history load.");
            return;
        }

        console.log("Fetching chat history (autoLoad:", autoLoad, ")...");

        const res = await fetch(`${API_BASE}/history`, {
            headers: { "Content-Type": "application/json", ...authHeaders() },
        });

        if (res.status === 401) {
            console.warn("401 Unauthorized — logging out user.");
            handleLoggedOut();
            return;
        }

        if (!res.ok) {
            console.error("Failed to fetch history. Status:", res.status);
            return;
        }

        const data = await res.json();
        console.log("History data received:", data);

        if (!Array.isArray(data) || data.length === 0) {
            console.log("No history items found.");
            if (historyList) historyList.innerHTML = "<div class='empty-history'>No chat history yet.</div>";
            return;
        }

        if (!historyList) {
            console.error("historyList element not found — cannot update history UI.");
            return;
        }

        // Clear current sidebar content safely
        historyList.innerHTML = "";

        // Populate history sidebar
        data.forEach((h, idx) => {
            if (!h.question || !h.answer) return;

            const item = document.createElement("div");
            item.className = "history-item";
            item.innerHTML = `
                <div class="history-title">${h.question.slice(0, 60)}</div>
                <div class="history-snippet">${h.answer.slice(0, 120)}</div>
            `;

            item.addEventListener("click", () => {
                if (!messagesEl) return;
                messagesEl.innerHTML = "";
                pushMessage("user", h.question);
                pushMessage("assistant", h.answer);
                messagesEl.scrollTop = messagesEl.scrollHeight;
                console.log(`Loaded chat ${idx + 1}: ${h.question}`);
            });

            historyList.appendChild(item);
        });

        // Auto-load the latest chat only if requested
        if (autoLoad && historyList.children.length > 0) {
            console.log("Auto-loading latest chat item...");
            historyList.children[0].click();
        } else {
            console.log("History updated without auto-load.");
        }

        // Smooth scroll for sidebar itself
        if (historyList.scrollHeight > historyList.clientHeight) {
            historyList.scrollTop = historyList.scrollHeight;
        }
    } catch (err) {
        console.error("Error while loading chat history:", err);
    } finally {
        isLoadingHistory = false;
    }
}

// -------------------- SEND QUERY --------------------
async function sendQuery(uploaded = false) {
    if (!promptEl) return;

    // Prevent sending new query while streaming
    if (isStreaming) {
        toast("Please wait for the current response to finish.");
        return;
    }

    const question = promptEl.value.trim();
    if (!question && !uploaded) {
        toast("Type a question or upload a file first.");
        return;
    }

    // 1. CLEAR THE INPUT FIELD IMMEDIATELY
    promptEl.value = ""; 
    
    // Display user message first
    pushMessage("user", question || "(uploaded file)");
    
    // Create the assistant message element with temporary loading text
    // The inner text will be immediately cleared by typewriterEffect
    let assistantMessageEl = pushMessage("assistant", '...'); 

    try {
        console.log("Starting sendQuery, uploaded:", uploaded);
        const body = {
            question,
            top_k: parseInt(document.getElementById("top-k")?.value) || 5
        };
        
        const res = await fetch(`${API_BASE}/query`, {
            method: "POST",
            headers: { "Content-Type": "application/json", ...authHeaders() },
            body: JSON.stringify(body),
        });

        if (res.status === 401) {
            handleLoggedOut();
            return;
        }

        const data = await res.json();
        const answer = data.answer || "No answer returned";
        const charDelay = 25;
        const totalTypingTime = answer.length * charDelay;
        const delayMs = totalTypingTime + 500; // Total delay for typing and buffer

        
        // 2. START STREAMING/TYPING EFFECT
        if (assistantMessageEl) {
            typewriterEffect(assistantMessageEl, answer, charDelay);
        } else {
            // Fallback
            pushMessage("assistant", answer);
        }

        if (data.sources && Array.isArray(data.sources)) {
            // Delay rendering sources until typing is complete
            setTimeout(() => {
                 renderSources(data.sources);
            }, delayMs); 
        }
        
        // Update sidebar history (wait for typing to finish to ensure the full answer is recorded)
        if (data.answer) {
            setTimeout(() => loadHistory(false), delayMs + 500); 
        }

    } catch (err) {
        console.error("SEND QUERY CATCH BLOCK EXECUTED. ERROR:", err.message, err);
        // Display error message
        if(assistantMessageEl) {
            const contentEl = assistantMessageEl.querySelector('.msg-content');
            if (contentEl) {
                // Remove cursor if typing started
                const cursor = contentEl.querySelector('.typing-cursor');
                if (cursor) cursor.remove();
                contentEl.innerHTML = "Error: " + err.message;
            }
            isStreaming = false; 
        } else {
            pushMessage("assistant", "Error: " + err.message);
        }
    }
}

// -------------------- UPLOAD FILE --------------------
async function uploadFile(file) {
    if (!file) {
        console.log("No file selected");
        return false;
    }
    if (file.size > 20 * 1024 * 1024) {
        toast("File too big (max 20MB)");
        return false;
    }

    const fd = new FormData();
    fd.append("file", file);

    try {
        console.log("Uploading file:", file.name);
        const res = await fetch(`${API_BASE}/upload`, {
            method: "POST",
            headers: authHeaders(),
            body: fd,
        });
        console.log("Upload fetch status:", res.status);

        if (res.status === 401) {
            handleLoggedOut();
            return false;
        }
        if (!res.ok) {
            const err = await res.json().catch(() => ({ detail: "Upload failed" }));
            toast("Upload failed: " + (err.detail || res.statusText));
            console.error("Upload error response:", err);
            return false;
        }

        const data = await res.json();
        console.log("Upload response:", data);
        toast("Uploaded: " + (data.filename || "ok"));
        await loadUserFiles(); // Refresh file list
        return true;
    } catch (err) {
        console.error("Upload error:", err);
        toast("Upload error");
        return false;
    }
}


// Function to fetch and display files (moved out of init for better access)
async function loadUserFiles() {
  const fileDropdown = document.getElementById("file-dropdown");
  if (!fileDropdown || !token) return;

  try {
    const res = await fetch(`${API_BASE}/documents`, {
      headers: {
        "Authorization": `Bearer ${token}`,
      },
    });

    if (!res.ok) throw new Error("Failed to fetch files");
    const data = await res.json();

    fileDropdown.innerHTML = ""; // clear existing list

    if (!data.documents || data.documents.length === 0) {
      fileDropdown.innerHTML = `<div class="muted small">No files uploaded</div>`;
      return;
    }

    data.documents.forEach((doc) => {
      const item = document.createElement("div");
      item.className = "file-item";
      item.innerHTML = `
        <span>${doc.filename}</span>
        <button class="delete-btn" data-filename="${doc.filename}" title="Delete">🗑️</button>
      `;
      fileDropdown.appendChild(item);
    });

    // Add delete event listeners
    document.querySelectorAll(".delete-btn").forEach((btn) => {
      btn.addEventListener("click", async (e) => {
        e.stopPropagation();
        const filename = e.target.getAttribute("data-filename");
        if (!confirm(`Delete ${filename}?`)) return;

        try {
          const delRes = await fetch(`${API_BASE}/documents/${filename}`, {
            method: "DELETE",
            headers: {
              "Authorization": `Bearer ${token}`,
            },
          });

          if (delRes.ok) {
            alert(`Deleted: ${filename}`);
            loadUserFiles(); // refresh dropdown
          } else {
            const err = await delRes.json();
            alert(`Error: ${err.detail}`);
          }
        } catch (err) {
          console.error(err);
          alert("Failed to delete file");
        }
      });
    });

  } catch (err) {
    console.error("Error loading user files:", err);
    fileDropdown.innerHTML = `<div class="muted small">Error loading files</div>`;
  }
}



// -------------------- INIT --------------------
(async function init() {
    // Initialize DOM elements
    fileInput = document.getElementById("file-input");
    sendBtn = document.getElementById("send-btn");
    uploadAndSendBtn = document.getElementById("upload-and-send");
    promptEl = document.getElementById("prompt");
    messagesEl = document.getElementById("messages");
    historyList = document.getElementById("history-list");
    newChatBtn = document.getElementById("new-chat");
    logoutBtn = document.getElementById("logout-btn");
    usernameDisplay = document.getElementById("username-display");
    footerUsername = document.getElementById("footer-username");

    // Debug missing DOM elements
    if (!fileInput) console.error("fileInput is null");
    if (!sendBtn) console.error("sendBtn is null");
    if (!uploadAndSendBtn) console.error("uploadAndSendBtn is null");
    if (!promptEl) console.error("promptEl is null");
    if (!messagesEl) console.error("messagesEl is null");
    if (!historyList) console.error("historyList is null");
    if (!newChatBtn) console.error("newChatBtn is null");
    if (!logoutBtn) console.error("logoutBtn is null");
    if (!usernameDisplay) console.error("usernameDisplay is null");
    if (!footerUsername) console.error("footerUsername is null");

    // Set username
    token = localStorage.getItem("token");
    username = localStorage.getItem("username") || username;
    if (usernameDisplay) usernameDisplay.textContent = username;
    if (footerUsername) footerUsername.textContent = username;

    // Set up event listeners
    if (sendBtn) {
        sendBtn.addEventListener("click", async e => {
            e.preventDefault();
            console.log("Send button clicked");
            await sendQuery(false);
        });
    }

    if (promptEl) {
        promptEl.addEventListener("keydown", e => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                console.log("Enter key pressed in prompt");
                sendQuery(false);
            }
        });
    }

    if (uploadAndSendBtn) {
        uploadAndSendBtn.addEventListener("click", async () => {
            const file = fileInput ? fileInput.files[0] : null;
            if (!file) {
                toast("Select a file first");
                return;
            }
            console.log("Upload and Send button clicked");
            const uploaded = await uploadFile(file);
            if (uploaded) await sendQuery(true);
        });
    }

    if (fileInput) {
        fileInput.addEventListener("change", async e => {
            const file = e.target.files[0];
            console.log("File selected:", file?.name);
            const uploaded = await uploadFile(file);
            // Do not send query here, as the user might want to type a question first
        });
    }

    if (newChatBtn) {
        newChatBtn.addEventListener("click", () => {
            if (messagesEl) {
                messagesEl.innerHTML = "";
                console.log("New chat started, messages cleared");
            }
        });
    }

    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.removeItem("token");
            localStorage.removeItem("username");
            token = null;
            handleLoggedOut();
        });
    }

    // Load files and history
    if (token) {
        console.log("Initializing with token, loading history and files...");
        await loadUserFiles();
        await loadHistory(true);
    } else {
        console.log("No token, skipping history and file load");
    }
})();