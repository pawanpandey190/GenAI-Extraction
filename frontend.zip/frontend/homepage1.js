// homepage.js — FINAL (with live status per file)
const API_BASE = "http://localhost:8001";
const POLL_INTERVAL = 3000;

document.addEventListener("DOMContentLoaded", () => {
  console.log("PPI Upload Page Loaded");

  const uploadBtn = document.getElementById("uploadBtn");
  const statusEl = document.getElementById("status");
  const jobInfo = document.getElementById("jobInfo");
  const downloadArea = document.getElementById("downloadArea");
  const resultArea = document.getElementById("resultArea");

  function show(msg, color = "orange") {
    statusEl.textContent = msg;
    statusEl.style.color = color;
  }

  uploadBtn.onclick = async () => {
    console.log("Upload clicked");
    show("Uploading...", "orange");
    uploadBtn.disabled = true;

    const fd = new FormData();
    const files = {
      rfp: document.querySelector("input[name='tender']")?.files[0],
      gtp: document.querySelector("input[name='gtp']")?.files[0],
      response: document.querySelector("input[name='response']")?.files[0],
      other: document.querySelector("input[name='other']")?.files[0]
    };

    if (!Object.values(files).some(f => f)) {
      show("No file selected", "red");
      uploadBtn.disabled = false;
      return;
    }

    for (const key in files) {
      if (files[key]) fd.append(key, files[key]);
    }

    try {
      const token = localStorage.getItem("token");
      if (!token) throw new Error("Login required");

      const res = await fetch(`${API_BASE}/upload_documents`, {
        method: "POST",
        headers: { Authorization: `Bearer ${token}` },
        body: fd
      });

      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || "Upload failed");

      resultArea.hidden = false;

      // 🧩 Map each document type to its task ID
      const taskPairs = data.task_ids; // e.g. [["RFP", "abc123"], ["GTP", "xyz456"]]
      jobInfo.innerHTML = `<ul>${taskPairs
        .map(([doc, id]) => `<li>${doc}: <code>${id.slice(0, 8)}...</code> → <span id="status-${id}">Waiting...</span></li>`)
        .join("")}</ul>`;

      show("Processing started...", "orange");

      await pollTaskStatus(taskPairs);

      show("✅ All tasks completed! Generate report below", "green");
      addReportButton(taskPairs.map(t => t[1]));

    } catch (e) {
      console.error(e);
      show("Error: " + e.message, "red");
    } finally {
      uploadBtn.disabled = false;
    }
  };

  // 🕒 Poll each task's status and update live
  async function pollTaskStatus(taskPairs) {
    console.log("🟢 pollTaskStatus started with:", taskPairs);
    let allDone = false;

    while (!allDone) {
      console.log("🔄 Poll iteration starting...");
      allDone = true;

      for (const [docType, taskId] of taskPairs) {
        try {
          const res = await fetch(`${API_BASE}/task_status/${taskId}/${docType}`, {
            headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
          });

          const data = await res.json();
          const state = (data.state || "PENDING").toUpperCase();
          console.log(`📊 ${docType} ${taskId} ${state}`);

          const el = document.getElementById(`status-${taskId}`);
          if (el) {
            let color = "gray";
            if (state === "SUCCESS") color = "green";
            else if (state === "STARTED") color = "orange";
            else if (state === "FAILURE") color = "red";
            el.textContent = state;
            el.style.color = color;
          }

          if (!["SUCCESS", "FAILURE"].includes(state)) {
            allDone = false; // continue polling
          }

        } catch (err) {
          console.error("Polling error:", err);
          allDone = false;
        }
      }

      if (!allDone) {
        await new Promise(r => setTimeout(r, POLL_INTERVAL));
      }
    }
  }

  function addReportButton(ids) {
    if (document.getElementById("reportBtn")) return;
    const btn = document.createElement("button");
    btn.id = "reportBtn";
    btn.textContent = "Generate Final Report";
    btn.style = "margin:15px 0; padding:10px 20px; background:green; color:white; border:none; border-radius:5px; font-weight:bold;";
    btn.onclick = async () => {
      btn.textContent = "Generating...";
      btn.disabled = true;
      try {
        const res = await fetch(`${API_BASE}/generate_final_report`, {
          method: "POST",
          headers: {
            Authorization: `Bearer ${localStorage.getItem("token")}`,
            "Content-Type": "application/json"
          },
          body: JSON.stringify({ task_ids: ids })
        });
        const d = await res.json();
        if (res.ok) {
          downloadArea.innerHTML = `
            <p><strong>Report Ready:</strong></p>
            <a href="${d.excel_path}" target="_blank" style="margin:0 10px;">Excel</a>
            <a href="${d.word_path}" target="_blank">Word</a>
          `;
        } else {
          throw new Error(d.detail);
        }
      } catch (e) {
        alert("Report failed: " + e.message);
      } finally {
        btn.disabled = false;
        btn.textContent = "Generate Final Report";
      }
    };
    resultArea.appendChild(btn);
  }
});
