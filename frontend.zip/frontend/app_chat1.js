// -------------------- CONFIG --------------------
const API_BASE = "http://localhost:8001";

// -------------------- DOM --------------------
let fileInput = null;
let sendBtn = null;
let uploadAndSendBtn = null;
let promptEl = null;
let messagesEl = null;
let historyList = null;
let newChatBtn = null;
let logoutBtn = null;
let usernameDisplay = null;
let footerUsername = null;
let bug_debug = '';

// -------------------- STATE --------------------
let token = localStorage.getItem("token");
let username = localStorage.getItem("username") || "Guest";

// -------------------- HELPERS --------------------
function authHeaders() {
    const token = localStorage.getItem("token");
    return token ? { "Authorization": "Bearer " + token } : {};
}

function pushMessage(role, text) {
    if (!messagesEl) {
        console.error("messagesEl is null, cannot push message");
        return;
    }
    if (!text || typeof text !== "string") {
        console.warn(`Invalid or empty text for ${role} message:`, text);
        return;
    }
    const el = document.createElement("div");
    el.className = "msg " + (role === "user" ? "user" : "");
    el.innerHTML = `
        <div class="msg meta">${role.toUpperCase()} • ${new Date().toLocaleString()}</div>
        <div>${text}</div>`;
    messagesEl.appendChild(el);
    // scrollToBottom();
    messagesEl.scrollTop = messagesEl.scrollHeight;
    console.log(`Pushed ${role} message:`, text);
}

function renderSources(sources) {
    if (!messagesEl) {
        console.error("messagesEl is null, cannot render sources");
        return;
    }
    if (!sources || !Array.isArray(sources) || sources.length === 0) {
        console.log("No valid sources to render:", sources);
        return;
    }
    const cont = document.createElement("div");
    cont.className = "msg sources";
    cont.innerHTML = `<div class="msg meta">SOURCES</div>` +
        sources.map(s => {
            if (typeof s === "string") {
                return `<div style="margin-top:6px;">${s.slice(0, 500)}</div>`;
            } else {
                return `<div style="margin-top:6px;">
                            <strong>${s.title || s.id || s.filename || "source"}</strong>
                            <div class="muted small">${(s.text_snippet || "").slice(0, 300)}</div>
                        </div>`;
            }
        }).join("");
    messagesEl.appendChild(cont);
    messagesEl.scrollTop = messagesEl.scrollHeight;
    console.log("Rendered sources:", sources);
}

function toast(msg) {
    alert(msg);
}

function handleLoggedOut() {
    toast("Session expired or logged out.");
    window.location.href = "/index.html";
}

// -------------------- CHAT HISTORY --------------------
let isLoadingHistory = false;

async function loadHistory(autoLoad = true) {
    // Prevent multiple parallel history loads
    if (isLoadingHistory) {
        console.log("Skipping loadHistory — already running.");
        return;
    }
    isLoadingHistory = true;

    try {
        if (!token) {
            console.log("No token found — skipping history load.");
            return;
        }

        console.log("Fetching chat history (autoLoad:", autoLoad, ")...");

        const res = await fetch(`${API_BASE}/history`, {
            headers: { "Content-Type": "application/json", ...authHeaders() },
        });

        if (res.status === 401) {
            console.warn("401 Unauthorized — logging out user.");
            handleLoggedOut();
            return;
        }

        if (!res.ok) {
            console.error("Failed to fetch history. Status:", res.status);
            return;
        }

        const data = await res.json();
        console.log("History data received:", data);

        if (!Array.isArray(data) || data.length === 0) {
            console.log("No history items found.");
            if (historyList) historyList.innerHTML = "<div class='empty-history'>No chat history yet.</div>";
            return;
        }

        if (!historyList) {
            console.error("historyList element not found — cannot update history UI.");
            return;
        }

        // Clear current sidebar content safely
        historyList.innerHTML = "";

        // Populate history sidebar
        data.forEach((h, idx) => {
            if (!h.question || !h.answer) return;

            const item = document.createElement("div");
            item.className = "history-item";
            item.innerHTML = `
                <div class="history-title">${h.question.slice(0, 60)}</div>
                <div class="history-snippet">${h.answer.slice(0, 120)}</div>
            `;

            item.addEventListener("click", () => {
                if (!messagesEl) return;
                messagesEl.innerHTML = "";
                pushMessage("user", h.question);
                pushMessage("assistant", h.answer);
                scrollToBottom();
                console.log(`Loaded chat ${idx + 1}: ${h.question}`);
            });

            historyList.appendChild(item);
        });

        // Auto-load the latest chat only if requested
        if (autoLoad && historyList.children.length > 0) {
            console.log("Auto-loading latest chat item...");
            historyList.children[0].click();
        } else {
            console.log("History updated without auto-load.");
        }

        // Smooth scroll for sidebar itself
        if (historyList.scrollHeight > historyList.clientHeight) {
            historyList.scrollTop = historyList.scrollHeight;
        }
    } catch (err) {
        console.error("Error while loading chat history:", err);
    } finally {
        isLoadingHistory = false;
    }
}

// -------------------- SEND QUERY --------------------
async function sendQuery(uploaded = false) {
    if (!promptEl) {
        console.error("promptEl is null, cannot send query");
        return;
    }
    const question = promptEl.value.trim();
    if (!question && !uploaded) {
        toast("Type a question or upload a file first.");
        return;
    }
    console.log("check")
    try {
        console.log("Starting sendQuery, uploaded:", uploaded);
        console.log(`Attempting fetch to: ${API_BASE}/query`);
        const body = {
            question,
            top_k: parseInt(document.getElementById("top-k")?.value) || 5
        };
        console.log(body,"body")
        const res = await fetch(`${API_BASE}/query`, {
            method: "POST",
            headers: { "Content-Type": "application/json", ...authHeaders() },
            body: JSON.stringify(body),
        });
        console.log(res.status,"res.status")
        if (res.status === 401) {
            console.log("entered the 401 error")
            handleLoggedOut();

            return;
        }

        const data = await res.json();
        const answer = data.answer || "No answer returned";
        console.log("*************")
        bug_debug+=answer

        
        // console.log("Delay finished. Displaying message.");

        // Display new messages without clearing old ones
        pushMessage("user", question || "(uploaded file)");
        pushMessage("assistant", answer);

        if (data.sources && Array.isArray(data.sources)) {
            renderSources(data.sources);
        }
        if (data.answer) {
        setTimeout(() => loadHistory(false), 1500); // delay avoids overlap
        }
        // Update sidebar history but don’t overwrite current chat
        // console.log("route to the history")
        // setTimeout(() => loadHistory(false), 500);
    } catch (err) {
        console.error("SEND QUERY CATCH BLOCK EXECUTED. ERROR:", err.message, err);
        pushMessage("assistant", "Error: " + err.message);
    } finally {
        if (promptEl) promptEl.value = "";
        // console.log("SEND QUERY FINISHED")
    }
}

// -------------------- UPLOAD FILE --------------------
async function uploadFile(file) {
    if (!file) {
        console.log("No file selected");
        return false;
    }
    if (file.size > 20 * 1024 * 1024) {
        toast("File too big (max 20MB)");
        return false;
    }

    const fd = new FormData();
    fd.append("file", file);

    try {
        console.log("Uploading file:", file.name);
        const res = await fetch(`${API_BASE}/upload`, {
            method: "POST",
            headers: authHeaders(),
            body: fd,
        });
        console.log("Upload fetch status:", res.status);

        if (res.status === 401) {
            handleLoggedOut();
            return false;
        }
        if (!res.ok) {
            const err = await res.json().catch(() => ({ detail: "Upload failed" }));
            toast("Upload failed: " + (err.detail || res.statusText));
            console.error("Upload error response:", err);
            return false;
        }

        const data = await res.json();
        console.log("Upload response:", data);
        toast("Uploaded: " + (data.filename || "ok"));
        await loadHistory(false);
        return true;
    } catch (err) {
        console.error("Upload error:", err);
        toast("Upload error");
        return false;
    }
}



// -------------------- INIT --------------------
(async function init() {
    // Initialize DOM elements
    fileInput = document.getElementById("file-input");
    sendBtn = document.getElementById("send-btn");
    uploadAndSendBtn = document.getElementById("upload-and-send");
    promptEl = document.getElementById("prompt");
    messagesEl = document.getElementById("messages");
    historyList = document.getElementById("history-list");
    newChatBtn = document.getElementById("new-chat");
    logoutBtn = document.getElementById("logout-btn");
    usernameDisplay = document.getElementById("username-display");
    footerUsername = document.getElementById("footer-username");

    // Debug missing DOM elements
    if (!fileInput) console.error("fileInput is null");
    if (!sendBtn) console.error("sendBtn is null");
    if (!uploadAndSendBtn) console.error("uploadAndSendBtn is null");
    if (!promptEl) console.error("promptEl is null");
    if (!messagesEl) console.error("messagesEl is null");
    if (!historyList) console.error("historyList is null");
    if (!newChatBtn) console.error("newChatBtn is null");
    if (!logoutBtn) console.error("logoutBtn is null");
    if (!usernameDisplay) console.error("usernameDisplay is null");
    if (!footerUsername) console.error("footerUsername is null");

    // Set username
    token = localStorage.getItem("token");
    username = localStorage.getItem("username") || username;
    if (usernameDisplay) usernameDisplay.textContent = username;
    if (footerUsername) footerUsername.textContent = username;

    // Set up event listeners
    if (sendBtn) {
        sendBtn.addEventListener("click", async e => {
            e.preventDefault();
            console.log("Send button clicked");
            await sendQuery(false);
        });
    }

    if (promptEl) {
        promptEl.addEventListener("keydown", e => {
            if (e.key === "Enter" && !e.shiftKey) {
                e.preventDefault();
                console.log("Enter key pressed in prompt");
                sendQuery(false);
            }
        });
    }

    if (uploadAndSendBtn) {
        uploadAndSendBtn.addEventListener("click", async () => {
            const file = fileInput ? fileInput.files[0] : null;
            if (!file) {
                toast("Select a file first");
                return;
            }
            console.log("Upload and Send button clicked");
            const uploaded = await uploadFile(file);
            if (uploaded) await sendQuery(true);
        });
    }

    if (fileInput) {
        fileInput.addEventListener("change", async e => {
            const file = e.target.files[0];
            console.log("File selected:", file?.name);
            await uploadFile(file);
        });
    }

    if (newChatBtn) {
        newChatBtn.addEventListener("click", () => {
            if (messagesEl) {
                messagesEl.innerHTML = "";
                console.log("New chat started, messages cleared");
            }
        });
    }

    if (logoutBtn) {
        logoutBtn.addEventListener("click", () => {
            localStorage.removeItem("token");
            localStorage.removeItem("username");
            token = null;
            handleLoggedOut();
        });
    }

//  for the uploaded file
document.addEventListener("DOMContentLoaded", () => {
  const fileDropdown = document.getElementById("file-dropdown");
  const token = localStorage.getItem("token");

  // Function to fetch and display files
  async function loadUserFiles() {
    try {
      const res = await fetch(`${API_BASE}/documents`, {
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });

      if (!res.ok) throw new Error("Failed to fetch files");
      const data = await res.json();

      fileDropdown.innerHTML = ""; // clear existing list

      if (!data.documents || data.documents.length === 0) {
        fileDropdown.innerHTML = `<div class="muted small">No files uploaded</div>`;
        return;
      }

      data.documents.forEach((doc) => {
        const item = document.createElement("div");
        item.className = "file-item";
        item.innerHTML = `
          <span>${doc.filename}</span>
          <button class="delete-btn" data-filename="${doc.filename}" title="Delete">🗑️</button>
        `;
        fileDropdown.appendChild(item);
      });

      // Add delete event listeners
      document.querySelectorAll(".delete-btn").forEach((btn) => {
        btn.addEventListener("click", async (e) => {
          e.stopPropagation();
          const filename = e.target.getAttribute("data-filename");
          if (!confirm(`Delete ${filename}?`)) return;

          try {
            const delRes = await fetch(`${API_BASE}/documents/${filename}`, {
              method: "DELETE",
              headers: {
                "Authorization": `Bearer ${token}`,
              },
            });

            if (delRes.ok) {
              alert(`Deleted: ${filename}`);
              loadUserFiles(); // refresh dropdown
            } else {
              const err = await delRes.json();
              alert(`Error: ${err.detail}`);
            }
          } catch (err) {
            console.error(err);
            alert("Failed to delete file");
          }
        });
      });

    } catch (err) {
      console.error("Error loading user files:", err);
      fileDropdown.innerHTML = `<div class="muted small">Error loading files</div>`;
    }
  }

  // Load files initially
  loadUserFiles();
});





    // Load history and auto-display latest on page load
    if (token) {
        console.log("Initializing with token, loading history...");
        await loadHistory(true);
        // await sendQuery(true);
    } else {
        console.log("No token, skipping history load");
    }
})();

